# GoDoCity Site (Astro)

Multi-city, newsletter-first local publication platform.
First city: GoDoDaytona (GoDo386)

## Cloudflare Pages settings
- Framework preset: **Astro**
- Build command: `npm run build`
- Build output directory: `dist`

## Local development (optional)
```bash
npm install
npm run dev
```
