---
city: daytona
title: "GoDoDaytona is live: what this is and what’s next"
description: "Our first city site is up. Here’s what we’ll cover, how to subscribe, and how businesses can advertise."
pubDate: 2026-01-12
tags: ["city","events","business"]
featured: true
---

Welcome to **GoDoDaytona** (nickname: **GoDo386**).

This MVP is intentionally simple:
- **Topics** and **Guides** navigation
- **Fast, mobile-first** layout
- Built to scale to new cities without rebuilding

Next steps:
1. Pick a newsletter provider (Beehiiv / Mailchimp / ConvertKit)
2. Start publishing 3–5 posts per week
3. Add a simple events feed
4. Build your first advertiser package
