---
city: daytona
section: play
title: "Play in Daytona"
description: "Things to do, beaches, parks, and weekend ideas."
---

## Start here

- Beaches, trails, and day trips
- Seasonal events
- “Best of” lists
